# Plan directory

Start here:
- `IMPLEMENTATION_PLAN.md` — overall plan and principles
- `QUALITY_GATES.md` — non-negotiable gates
- `WORK_BREAKDOWN_STRUCTURE.md` — epics and work packages
- `RISK_REGISTER.md` — major risks and mitigations
- `phases/` — detailed phase documents
