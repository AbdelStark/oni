---
name: Bug report
about: Report a bug in oni
title: "[bug] "
labels: bug
assignees: ""
---

## Summary

## Environment
- OS:
- Erlang/OTP version:
- Gleam version:
- oni commit / tag:

## Steps to reproduce

## Expected behavior

## Actual behavior

## Logs / telemetry
(Please redact secrets.)

## Additional context
