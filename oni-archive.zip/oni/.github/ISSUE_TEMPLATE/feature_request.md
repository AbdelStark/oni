---
name: Feature request
about: Propose a feature or enhancement
title: "[feature] "
labels: enhancement
assignees: ""
---

## Problem

## Proposed solution

## Alternatives considered

## Scope
- Consensus impact? (yes/no)
- P2P impact? (yes/no)
- Storage impact? (yes/no)
- RPC impact? (yes/no)

## Acceptance criteria
